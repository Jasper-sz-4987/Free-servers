"""mcp_agent_notes — structured, prioritized onboarding knowledge for MCP servers.

Distinct from mcp-events (runtime, per-call warnings riding along in one tool's
response) -- this is static, per-connection knowledge, authored ahead of time by
whoever maintains the server, delivered two ways:

  - `render_instructions()` -- a small, bounded blob sent once, verbatim, in
    the `initialize` handshake's `InitializeResult.instructions` (the one MCP
    channel that reaches every client, not just ones with a local checkout
    and a Claude-Code-style auto-loaded project file).
  - `strategy()` / `tactics()` / `find()` -- a tool a consuming server
    registers (see SPEC.md, design-docs/mcp-agent-notes/) so an agent can
    pull full detail on demand, by topic or by free-text problem
    description, without the corpus needing to be small enough to inline.

Wire format stability: `Note`'s field names are the stable authoring contract
for consuming projects. Adding a field is backward-compatible; renaming or
removing one is breaking and needs a version bump. This module's public shape
(fields, function signatures) reflects the design-docs/mcp-agent-notes/SPEC.md
revision -- the original v0.1.0 prototype (`render_full`, no strategy/tactic
split, no `addresses`) has been superseded; nothing external depended on it.
"""
from __future__ import annotations

import re
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from datetime import date, timedelta
from enum import Enum

__version__ = "0.2.0"
__all__ = [
    "Note",
    "NoteKind",
    "Priority",
    "find",
    "find_notes",
    "render_instructions",
    "strategy",
    "tactics",
]


class Priority(Enum):
    """Reuses the Critical/High/Medium/Low vocabulary already used for
    code-review and audit findings in this project family, rather than
    inventing a parallel one."""

    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class NoteKind(Enum):
    """What QUESTION a note answers -- orthogonal to Priority, which is
    urgency. A CRITICAL TACTIC is exactly as urgent as a CRITICAL STRATEGY."""

    STRATEGY = "strategy"  # what am I trying to do; what are my options
    TACTIC = "tactic"      # given a plan, how do I execute this one step


_PRIORITY_RANK: dict[Priority, int] = {
    Priority.CRITICAL: 0,
    Priority.HIGH: 1,
    Priority.MEDIUM: 2,
    Priority.LOW: 3,
}


@dataclass(frozen=True)
class Note:
    """One piece of durable, authored knowledge a maintainer wants future
    sessions -- any assistant, any client -- to know without having to
    rediscover it live.

    id: stable slug, e.g. "compound-check-solid-blind-spot". Used only for
        deterministic tie-breaking when sorting; never rendered to the model.
    added: the date this note was written. Drives which notes surface in the
        "recently added" section of the compact render regardless of priority.
    priority: urgency, independent of kind. CRITICAL/HIGH always considered
        for the compact render; MEDIUM/LOW only appear there if also recent.
    kind: STRATEGY (what am I trying to do, what are my options) or TACTIC
        (given a plan, how do I execute this one step). Shape of the content,
        not its importance -- see `Priority`.
    summary: one line. Must stand alone -- this is what the compact render
        and every one-liner fallback show, with no surrounding detail.
    detail: full body, markdown. Falls back to `summary` when empty.
    tags: topic/subsystem identifiers this note is about. Drives
        topic-conditional relevance for `strategy()`'s no-topic overview and
        `tactics()`'s topic listing -- empty tags means "universal," always
        eligible regardless of what's active (the empty set is a subset of
        every set).
    addresses: problem/symptom phrasings, authored separately from `summary`,
        that `find_notes()` matches a free-text query against -- not for
        display.
    location: an external pointer (URL, file path, MCP resource URI) for
        material too large to flatten into `detail` (a full manual, a module
        reference). Rendering surfaces the pointer; nothing here fetches or
        inlines whatever it points at.
    """

    id: str
    added: date
    priority: Priority
    kind: NoteKind
    summary: str
    detail: str = ""
    tags: tuple[str, ...] = ()
    addresses: tuple[str, ...] = ()
    location: str | None = None


def _sort_key(note: Note) -> tuple[int, int, str]:
    # Priority ascending (Critical first), then most-recent-first within a
    # tier (negate via ordinal day count since date isn't natively
    # negatable), then id as a final deterministic tiebreaker for notes
    # added on the same day.
    return (_PRIORITY_RANK[note.priority], -note.added.toordinal(), note.id)


def _render_note_full(note: Note) -> str:
    body = note.detail if note.detail else note.summary
    lines = [f"## {note.summary}", body]
    if note.location:
        lines.append(f"See: {note.location}")
    return "\n".join(lines)


def render_instructions(
    notes: Sequence[Note],
    *,
    capability_statement: str,
    query_tool_name: str,
    now: date | None = None,
    recent_days: int = 30,
    max_notes: int = 8,
) -> str:
    """Render the compact string for InitializeResult.instructions (or
    FastMCP's own `instructions=`).

    Deliberately topic-blind: this handshake happens once per connection,
    with no protocol primitive to re-send it later, while which topics are
    "active" is runtime state that can change mid-session (e.g. a JMRI
    subsystem enabled for the first time after years unused). Gating this
    one-shot blob by an active-topics snapshot taken at connect time would
    risk a note going invisible for the rest of the session right as it
    becomes relevant -- worse than the alternative of always showing it. All
    topic-conditional behavior lives in `strategy()`/`tactics()` instead,
    which are called per-request and so always reflect current state.

    Three parts, always in this order:
      1. `capability_statement`, verbatim (a hand-authored blurb, not
         derived from notes -- omitted entirely if empty).
      2. Importance + recency: every CRITICAL note, always, never truncated
         by `max_notes`; HIGH notes filling whatever budget remains after
         criticals; then anything (any priority) added within `recent_days`
         that isn't already shown, deduplicated by id.
      3. Fixed-size calling convention naming `query_tool_name` and its
         operations -- the part that keeps this blob constant-size
         regardless of corpus size, since it names the tool, not topics.

    Only ever renders `summary` (one-liners) -- never `detail`, for any
    note, at any priority. Full detail by topic is `strategy()`/`tactics()`'s
    job.
    """
    today = now if now is not None else date.today()
    ordered = sorted(notes, key=_sort_key)

    criticals = [n for n in ordered if n.priority is Priority.CRITICAL]
    highs = [n for n in ordered if n.priority is Priority.HIGH]
    budget_remaining = max(0, max_notes - len(criticals))
    highlighted = criticals + highs[:budget_remaining]
    highlighted_ids = {n.id for n in highlighted}

    cutoff = today - timedelta(days=recent_days)
    recent = [
        n for n in ordered
        if n.id not in highlighted_ids and n.added >= cutoff
    ]

    sections: list[str] = []
    if capability_statement:
        sections.append(capability_statement)

    if highlighted:
        block = ["Key things to know:"] + [f"- {n.summary}" for n in highlighted]
        sections.append("\n".join(block))

    if recent:
        block = ["Recently added:"] + [f"- {n.summary}" for n in recent]
        sections.append("\n".join(block))

    sections.append(
        f'For more, call {query_tool_name}(operation="strategy") for a '
        f'tiered overview, {query_tool_name}(operation="strategy"|"tactics", '
        f'topic="...") for one topic in full, or {query_tool_name}'
        f'(operation="find", problem="...") to search by symptom.'
    )

    return "\n\n".join(sections)


def strategy(
    notes: Sequence[Note],
    *,
    topic: str | None = None,
    active_topics: frozenset[str] = frozenset(),
) -> str:
    """Query-tool operation `strategy` (SPEC.md §8b).

    No `topic`: tiered overview of every STRATEGY note -- full detail for
    notes whose tags are a subset of `active_topics` (an untagged note's
    empty tag set is a subset of anything, so it's always full detail), a
    one-liner for the rest.

    With `topic`: full detail for that topic's STRATEGY note(s),
    unconditionally, regardless of `active_topics` -- naming a topic
    explicitly is a fresher, more direct signal than a background-computed
    active-topics snapshot, especially right as a subsystem is first being
    stood up (SPEC.md §5).
    """
    candidates = sorted(
        (n for n in notes if n.kind is NoteKind.STRATEGY), key=_sort_key
    )

    if topic is not None:
        matched = [n for n in candidates if topic in n.tags]
        if not matched:
            return f'No strategy notes found for topic "{topic}".'
        return "\n\n".join(_render_note_full(n) for n in matched)

    if not candidates:
        return "No strategy notes available."

    full: list[Note] = []
    oneliners: list[Note] = []
    for n in candidates:
        (full if set(n.tags) <= active_topics else oneliners).append(n)

    sections: list[str] = []
    if full:
        sections.append("\n\n".join(_render_note_full(n) for n in full))
    if oneliners:
        block = ["Also available:"] + [f"- {n.summary}" for n in oneliners]
        sections.append("\n".join(block))
    return "\n\n".join(sections)


def tactics(notes: Sequence[Note], *, topic: str | None = None) -> str:
    """Query-tool operation `tactics` (SPEC.md §8b).

    No `topic`: list of available tactical topics, generated live from
    TACTIC notes' `tags` -- not hand-maintained, so it can't drift.

    With `topic`: full detail for that tactical topic, unconditionally --
    same "explicit ask beats a stale active-topics snapshot" reasoning as
    `strategy()`.
    """
    candidates = [n for n in notes if n.kind is NoteKind.TACTIC]

    if topic is not None:
        matched = sorted(
            (n for n in candidates if topic in n.tags), key=_sort_key
        )
        if not matched:
            return f'No tactic notes found for topic "{topic}".'
        return "\n\n".join(_render_note_full(n) for n in matched)

    topics = sorted({t for n in candidates for t in n.tags})
    if not topics:
        return "No tactical topics available."
    return "Available tactical topics: " + ", ".join(topics)


_TOKEN_RE = re.compile(r"[a-z0-9]+")


def _tokenize(text: str) -> frozenset[str]:
    return frozenset(_TOKEN_RE.findall(text.lower()))


def _default_scorer(query: str, note: Note) -> float:
    query_tokens = _tokenize(query)
    if not query_tokens:
        return 0.0
    addresses_overlap = len(query_tokens & _tokenize(" ".join(note.addresses)))
    if addresses_overlap:
        # Tier-separated (+1000) so any `addresses` match always outranks
        # any summary-only fallback match, regardless of overlap count on
        # either side -- addresses is the primary field, summary a fallback,
        # not two pools blended by raw count.
        return 1000.0 + addresses_overlap
    return float(len(query_tokens & _tokenize(note.summary)))


def find_notes(
    notes: Sequence[Note],
    query: str,
    *,
    top_n: int = 5,
    scorer: Callable[[str, Note], float] | None = None,
) -> list[Note]:
    """Rank notes by relevance to a free-text problem description.

    Default scorer: keyword/token overlap against `addresses` (primary) and
    `summary` (fallback). Deliberately not semantic -- see SPEC.md §6 non-
    goals. `scorer` is the held-open seam for a future semantic matcher to
    operate on the same `Note` objects with zero data migration.

    Returns `[]` for `top_n <= 0`, empty `notes`, or a blank/whitespace-only
    `query` -- all degenerate inputs pinned explicitly rather than left to
    fall out of slicing semantics (e.g. a negative `top_n` is NOT "all but
    the last N", it's "nothing").
    """
    if top_n <= 0 or not notes or not query.strip():
        return []
    score = scorer if scorer is not None else _default_scorer
    scored = [(score(query, n), n) for n in notes]
    scored = [(s, n) for s, n in scored if s > 0]
    scored.sort(key=lambda pair: (-pair[0], _sort_key(pair[1])))
    return [n for _, n in scored[:top_n]]


def find(
    notes: Sequence[Note],
    problem: str,
    *,
    top_n: int = 5,
    scorer: Callable[[str, Note], float] | None = None,
) -> str:
    """Query-tool operation `find` (SPEC.md §8b): `find_notes()` results,
    both kinds, ranked, each labeled with its `kind` and rendered in full."""
    results = find_notes(notes, problem, top_n=top_n, scorer=scorer)
    if not results:
        return f'No notes found matching "{problem}".'

    blocks: list[str] = []
    for n in results:
        block = [f"[{n.kind.value.upper()}] {n.summary}"]
        if n.detail:
            block.append(n.detail)
        if n.location:
            block.append(f"See: {n.location}")
        blocks.append("\n".join(block))
    return "\n\n".join(blocks)
